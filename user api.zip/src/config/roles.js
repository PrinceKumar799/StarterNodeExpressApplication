const roles = {
  User: 4294,
  Admin: 1502,
  Editor: 1442,
};

module.exports = roles;
